#Using find command find the list of pdf and jpeg files. Also list their count.

echo "Enter the option"
read option
case "$option" in
	"1") find -iname '*.pdf'   #command to find pdf files
	;;
	"2") find -iname '*.jpg'  #command to fing JPG files
	;;
esac
